import requests
import json
from datetime import date 
from dotenv import load_dotenv
import os

API_URL = "https://zycbexpitl.execute-api.us-east-1.amazonaws.com/dev/api/blogs/create"

load_dotenv()

blog_data = {
    "title": "as;lkjf;sdjf;s",
    "description": "a;lsdkjflajf",
    "body": "a;sldkjfl;asfjdasf",
    "slug": "bruh",
}

try:
    headers = {"X-API-Key": "hOoxqjKGV5EdgP8gZA8tOaimwM8v99kqDyqbzW6SGHaIY5lBpxhhJiGVADfHEgsX"}
    response = requests.post(API_URL, headers=headers, json=blog_data)
    response.raise_for_status()
    print("executed successfully.")

except requests.exceptions.HTTPError as http_err:
    print(f"HTTP Error: {http_err}")
    print(f"Response content: {response.text}") 
except requests.exceptions.ConnectionError as conn_err:
    print(f"Error Connecting: {conn_err}")
except requests.exceptions.Timeout as timeout_err:
    print(f"Timeout Error: {timeout_err}")
except requests.exceptions.RequestException as req_err:
    print(f"An Unexpected Error occurred: {req_err}")


