import requests
import json
from datetime import date 

API_URL = "https://42706ole0h.execute-api.us-east-2.amazonaws.com/dev/api/blogs/delete/you-got-out-of-line-you-got-whacked"

blog_data = {
    "title": "you got out of line, you got whacked",
    "description": "goodfellas review",
    "body": """<p><span style="font-weight: 400;"><img src="https://d13jj08vfqimqg.cloudfront.net/uploads/film/photo_2/6228/full_Goodfellas2-1920x1080.jpg" alt="" width="1280" height="720" /></span></p>
<p>&nbsp;</p>
<p>Goodfellas is about a man called Henry Hill (rest in peace, Ray Liotta) who navigates the world of organized Italian-American crime. The film lacks a specific plot direction, but more so captures the energy of what it&rsquo;s like to be a mobster, bringing us through Hill&rsquo;s childhood, marriage, prime, and eventual downfall.&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">I think the character of Jimmy Conway was particularly interesting. His strong rapport with Henry Hill led me to believe that their relationship was built on loyalty and brotherhood, but I quickly realized that gangsters do whatever it takes to survive, even if it means killing your own. In one of the last scenes of the film, Conway tries to kill Hill&rsquo;s wife, Karen, by offering her &ldquo;Dior Dresses&rdquo; in the back of a dark alleyway, which Karen sees through. Conway is also the most calculated and seasoned mobster in the family. After the Lufthansa heist, many of the gangsters quickly spent their money on lavish goods, much to Conway&rsquo;s disgust and disapproval, as the FBI could easily see them as key suspects if they spent too much money directly after committing the robbery.&nbsp;</span></p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">Tommy Devito (Joe Pesci) is truly a delight throughout Goodfellas. He&rsquo;s rambunctious, unpredictable, and volatile, which causes many plot changes throughout the story. For instance, in perhaps my favorite scene of the film, Devito curses and bullies a bartender, eventually shooting him in the foot after getting too drunk. A few weeks later, he returns to curse at him and threaten him again, but this time, the waiter fights back, remarking&ldquo;why don&rsquo;t you go f*ck yourself&rdquo;. Conway and Hill are both supportive of the waiter, who, to their surprise, has enough balls to talk to Devito like that. Devito doesn&rsquo;t take it and shoots the poor waiter five times in the chest, killing him. His sudden bursts of violence are iconic, and I&rsquo;m glad Pesci received his much-deserved Oscar for the role.&nbsp;</span></p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">The last member of the family I&rsquo;m going to talk about is Paul Cicero. Although he is often quiet, his understated demeanor speaks volumes about his strict rules (no drugs) that Hill eventually breaks, leading him to be essentially excommunicated. Cicero is a powerful character who acts as the overseer or the glue of the mob.&nbsp;</span></p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">There are so many memorable scenes from </span><em><span style="font-weight: 400;">Goodfellas. </span></em><span style="font-weight: 400;">The &ldquo;Funny How?&rdquo; scene with Devito and Hill, the scene where the mobsters bury Billy Batts, and the Witness Protection Hearing. I could talk about them all day, but for the sake of brevity, I&rsquo;ll just recommend that you watch the film. I think </span><em><span style="font-weight: 400;">Goodfellas</span></em><span style="font-weight: 400;">, ultimately, is not about a protagonist and an antagonist. It&rsquo;s about the glory of mob life and the lows of mob life. It&rsquo;s about the violence, paranoia, and lack of loyalty beneath the surface. It&rsquo;s nothing like </span><em><span style="font-weight: 400;">The Godfather.&nbsp;</span></em></p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">I haven&rsquo;t watched many of Martin Scorsese&rsquo;s films. The only Scorsese film I&rsquo;ve watched is </span><em><span style="font-weight: 400;">Wolf of Wall Street, </span></em><span style="font-weight: 400;">and it snuck its way into my favorites list despite the convoluted last 30 minutes because of its humor and sheer shock factor. In the first hour of </span><em><span style="font-weight: 400;">Goodfellas, </span></em><span style="font-weight: 400;">it's evident that I&rsquo;m watching a Scorsese film. The freeze frames, lack of concrete plot, and protagonist narration were all similarities that I thoroughly enjoyed coming from </span><em><span style="font-weight: 400;">The Wolf of Wall Street.&nbsp;</span></em></p>
<p>&nbsp;</p>
<p><span style="font-weight: 400;">However, I thought that Goodfellas wasn&rsquo;t anything exceptional. Sure, the last thirty minutes of the film were unique, accurately capturing Hill&rsquo;s life on the edge and eventual betrayal of the family. Sure, the story was quite intriguing, and I didn&rsquo;t feel the need to skip forward. But I struggle to find a reason for this film to be rated higher than something like </span><em><span style="font-weight: 400;">A Complete Unknown </span></em><span style="font-weight: 400;">or </span><em><span style="font-weight: 400;">1917, </span></em><span style="font-weight: 400;">or one of my all-time favorites, </span><em><span style="font-weight: 400;">The</span></em> <em><span style="font-weight: 400;">Wolf of Wall Street</span></em><span style="font-weight: 400;">.&nbsp;</span></p>""",
    "slug": "you-got-out-of-line-you-got-whacked",
}

try:
    headers = {"X-API-Key": "hOoxqjKGV5EdgP8gZA8tOaimwM8v99kqDyqbzW6SGHaIY5lBpxhhJiGVADfHEgsX"}
    response = requests.delete(API_URL, headers=headers)
    response.raise_for_status()
    print("executed successfully.")

except requests.exceptions.HTTPError as http_err:
    print(f"HTTP Error: {http_err}")
    print(f"Response content: {response.text}") # Print raw response content for debugging
except requests.exceptions.ConnectionError as conn_err:
    print(f"Error Connecting: {conn_err}")
except requests.exceptions.Timeout as timeout_err:
    print(f"Timeout Error: {timeout_err}")
except requests.exceptions.RequestException as req_err:
    print(f"An Unexpected Error occurred: {req_err}")


